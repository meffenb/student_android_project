﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace App1
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        int numer1 = 0;
        int numer2 = 0;
        int wynik_rownania = 0;
        string operacja = "";

        public MainPage()
        {
            this.InitializeComponent();
            Plus.IsEnabled = false;
            Minus.IsEnabled = false;
            Dziel.IsEnabled = false;
            Mnoz.IsEnabled = false;
        }

        private void cyfra_1_Click(object sender, RoutedEventArgs e)
        {
            Wynik.Text = Wynik.Text + "1";
            Plus.IsEnabled = true;
            Minus.IsEnabled = true;
            Dziel.IsEnabled = true;
            Mnoz.IsEnabled = true;
        }

        private void cyfra_2_Click(object sender, RoutedEventArgs e)
        {
            Wynik.Text = Wynik.Text + "2";
            Plus.IsEnabled = true;
            Minus.IsEnabled = true;
            Dziel.IsEnabled = true;
            Mnoz.IsEnabled = true;
        }

        private void cyfra_3_Click(object sender, RoutedEventArgs e)
        {
            Wynik.Text = Wynik.Text + "3";
            Plus.IsEnabled = true;
            Minus.IsEnabled = true;
            Dziel.IsEnabled = true;
            Mnoz.IsEnabled = true;
        }

        private void cyfra_4_Click(object sender, RoutedEventArgs e)
        {
            Wynik.Text = Wynik.Text + "4";
            Plus.IsEnabled = true;
            Minus.IsEnabled = true;
            Dziel.IsEnabled = true;
            Mnoz.IsEnabled = true;
        }

        private void cyfra_5_Click(object sender, RoutedEventArgs e)
        {
            Wynik.Text = Wynik.Text + "5";
            Plus.IsEnabled = true;
            Minus.IsEnabled = true;
            Dziel.IsEnabled = true;
            Mnoz.IsEnabled = true;
        }

        private void cyfra_6_Click(object sender, RoutedEventArgs e)
        {
            Wynik.Text = Wynik.Text + "6";
            Plus.IsEnabled = true;
            Minus.IsEnabled = true;
            Dziel.IsEnabled = true;
            Mnoz.IsEnabled = true;
        }

        private void cyfra_7_Click(object sender, RoutedEventArgs e)
        {
            Wynik.Text = Wynik.Text + "7";
            Plus.IsEnabled = true;
            Minus.IsEnabled = true;
            Dziel.IsEnabled = true;
            Mnoz.IsEnabled = true;
        }

        private void cyfra_8_Click(object sender, RoutedEventArgs e)
        {
            Wynik.Text = Wynik.Text + "8";
            Plus.IsEnabled = true;
            Minus.IsEnabled = true;
            Dziel.IsEnabled = true;
            Mnoz.IsEnabled = true;
        }

        private void cyfra_9_Click(object sender, RoutedEventArgs e)
        {
            Wynik.Text = Wynik.Text + "9";
            Plus.IsEnabled = true;
            Minus.IsEnabled = true;
            Dziel.IsEnabled = true;
            Mnoz.IsEnabled = true;
        }

        private void cyfra_0_Click(object sender, RoutedEventArgs e)
        {
            Wynik.Text = Wynik.Text + "0";
            Plus.IsEnabled = true;
            Minus.IsEnabled = true;
            Dziel.IsEnabled = true;
            Mnoz.IsEnabled = true;
        }

        private void Plus_Click(object sender, RoutedEventArgs e)
        {
            numer1 = Convert.ToInt32(Wynik.Text);
            operacja = "+";
            Plus.IsEnabled = false;
            Minus.IsEnabled = false;
            Dziel.IsEnabled = false;
            Mnoz.IsEnabled = false;
            Wynik.Text = String.Empty;
        }

        private void Minus_Click(object sender, RoutedEventArgs e)
        {
            numer1 = Convert.ToInt32(Wynik.Text);
            operacja = "-";
            Plus.IsEnabled = false;
            Minus.IsEnabled = false;
            Dziel.IsEnabled = false;
            Mnoz.IsEnabled = false;
            Wynik.Text = String.Empty;
        }

        private void Dziel_Click(object sender, RoutedEventArgs e)
        {
            numer1 = Convert.ToInt32(Wynik.Text);
            operacja = "/";
            Plus.IsEnabled = false;
            Minus.IsEnabled = false;
            Dziel.IsEnabled = false;
            Mnoz.IsEnabled = false;
            Wynik.Text = String.Empty;
        }

        private void Mnoz_Click(object sender, RoutedEventArgs e)
        {
            numer1 = Convert.ToInt32(Wynik.Text);
            operacja = "*";
            Plus.IsEnabled = false;
            Minus.IsEnabled = false;
            Dziel.IsEnabled = false;
            Mnoz.IsEnabled = false;
            Wynik.Text = String.Empty;
        }

        private void Rownasie_Click(object sender, RoutedEventArgs e)
        {
            numer2 = Convert.ToInt32(Wynik.Text);
            if(operacja == "+")
            {
                wynik_rownania = numer1 + numer2;
            } else if (operacja == "-")
            {
               wynik_rownania = numer1 - numer2;
            } else if (operacja == "/")
            {
                wynik_rownania = numer1 / numer2;
            }
            else if (operacja == "*")
            {
                wynik_rownania = numer1 * numer2;
            }
            Plus.IsEnabled = true;
            Minus.IsEnabled = true;
            Dziel.IsEnabled = true;
            Mnoz.IsEnabled = true;
            Wynik.Text = wynik_rownania.ToString();
        }

        private void Wyczysc_Click(object sender, RoutedEventArgs e)
        {
            historia.Text = numer1 + operacja + numer2 + "=" + wynik_rownania + "\n" + historia.Text;
            Wynik.Text = String.Empty;
            numer2 = 0;
            numer1 = 0;
            operacja = "";
        }
    }
}
